<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'dijTECH');
define('DB_PASSWORD', '23519480');
define('DB_DATABASE', 'medbook-dev-backend');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>